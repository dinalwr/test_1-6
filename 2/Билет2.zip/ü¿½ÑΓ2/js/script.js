document.getElementById('button1').addEventListener('click', function() {
    window.location.href = window.location.href;
});

let counter = 0;
document.getElementById('button2').addEventListener('click', function() {
    counter++;
    document.getElementById('counter').textContent = counter;
});

document.getElementById('button3').addEventListener('click', function() {
    document.body.style.backgroundColor = document.body.style.backgroundColor === 'lightblue' ? '#f0f0f0' : 'lightblue';
});
